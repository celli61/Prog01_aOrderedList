package Prog01_aOrderedList;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

/**
* Prog01_aOrderedList is the main class for managing an ordered list of cars read from an input file, 
* processing the file input, and writing the modified list to an output file
*
* CSC 1351 Programming Project No 1
* Section 2
*
* @author Colton Elliott
* @since 3/17/24
*
*/
public class Prog01_aOrderedList {
	static Scanner scan=new Scanner(System.in); //initializing static scanner for inputs from console
	
	/**
	* the main method is the entry point to the program, containing all the code to conduct the entire program flow,
	* including file I/O operations, manipulation of the ordered list of cars, and user interaction
	*
	* CSC 1351 Programming Project No 1
	* Section 2
	*
	* @author Colton Elliott
	* @since 3/17/24
	*
	*/
	public static void main(String[] args) throws FileNotFoundException {
		aOrderedList<Car> carList=new aOrderedList<Car>(); //initializing a new aOrderedList of Car objects 
		System.out.println("Please enter the file name/path for the read file: "); //prompting the user to input the file path
		Scanner readFile=GetInputFile(scan.nextLine()); /*initializing a scanner for reading from the input file using GetInputFile() method on the
		 												  prompted user input*/
		ArrayList<String> carsInfo=new ArrayList<>(); //initializing a String ArrayList to store the individual lines of the csv formatted input file
		
		while(readFile.hasNext()) { //initializing a while loop to iterate until the last line of the input file
			carsInfo.add(readFile.nextLine()); //adding each line as a whole string to the carsInfo ArrayList
		}
		
		for(String info:carsInfo) { //initializing a for loop to iterate over every String in the ArrayList carsInfo
			String[] infoString=info.split(","); /*storing the String from the current iteration through carsInfo as a String Array called infoString
												   using the String.split() method to split the line from csv format into individual strings*/
			if(infoString[0].equalsIgnoreCase("A")) { /*checking to see if the first character of the current line referenced with infoString is 
														String "A", indicating to add a new car with the parameters contained in the subsequent
														spots of infoString to carList*/
				Car car = new Car(infoString[1],Integer.parseInt(infoString[2]),Integer.parseInt(infoString[3])); /*initializing a new Car object with
				 																									the parameters contained at indexes
				 																									2,3, and 4 of infoString, representing
				 																									the make, year, and price of the car respectively*/
				carList.add(car); //adding the newly initialized Car to carList
			}
			else if(infoString[0].equalsIgnoreCase("D")) { /*if prior condition is not met, checking to see if the first character is String "D"
															indicating to delete a car from the list with the parameters contained in the subsequent 
															indexes of infoString*/
				Car checkCar = new Car(infoString[1], Integer.parseInt(infoString[2]), 0); /*initializing a Car object with the parameters from 
																							infoString to use in the compareTo() method while 
																							iterating over carList to find the indicated Car object*/
				carList.reset(); //resetting the iterator index for carList
				while(carList.hasNext()) { //initializing a while loop to iterate until the last object in carList
					Car currCar = carList.next(); //storing the call to carList.next() as a Car object for comparison
					if(checkCar.compareTo(currCar)==0) { //checking if the Car object from the current iteration is the Car object being searched for
						carList.remove(); //if the Car returned by the last call to .next() stored in currCar is the same as checkCar, remove it from carList with .remove()
						break; //break the loop since the Car was found and removed 
					}
				}
			}
		}
		System.out.println("Please enter the file name/path for the write file: "); //prompting the user to input the output file path
		PrintWriter writeFile=GetOutputFile(scan.nextLine()); /**initializing a scanner for writing to the output file using GetOutputFile() method on the
		 												  prompted user input*/
		writeFile.printf("Number of cars:\t%8d\n",carList.size()); //Printing a header that displays the total number of cars to the output file
		for(int i=0;i<carList.size();i++) { //initializing a for loop to iterate from 0 to the final index of carList
			writeFile.printf("\nMake:\t%8s\nYear:\t%8d\nPrice:\t%,8d\n",((Car) carList.get(i)).getMake(),((Car) carList.get(i)).getYear(),
							 ((Car) carList.get(i)).getPrice()); /*using the printf() method to write the information for the Car at index i of 
							 									 carList in a pretty format to output files PrintWriter, writeFile*/
		}
		writeFile.close(); //closing the PrintWriter to save the changes to the output file
	}
	
	/**
	* The GetInputFile method prompts the user to enter a file name or path, attempts to open the specified file for reading, 
	* and returns a Scanner object initialized to read from the file if successful.
	*
	* CSC 1351 Programming Project No 1
	* Section 2
	*
	* @author Colton Elliott
	* @since 3/17/24
	*
	*/
	public static Scanner GetInputFile(String UserPrompt) throws FileNotFoundException {
		String input=UserPrompt; //initializing a String to store user input in
		boolean termLoop=false; //initializing a boolean terminal variable for a loop
		do { //iterate at least once before checking terminal value each iteration, until proper input is achieved with the try catch
			try { 
				File readFile=new File(input); //initialize a File called readFile from the String input
				Scanner returnScanner=new Scanner(readFile); //try to create a Scanner to read from readFile
				System.out.println("File found. Reading from file."); //if Scanner is created, print a message to the console notifying success
				return returnScanner;
			}
			catch(Exception e) { //if an exception occurs 
				System.out.println("File not found. Would you like to re-enter the file name/path?<y/n>: "); /*print message to console notifying failure to create Scanner
																												and ask if the user would like to attempt to re-enter the 
																												file path*/
				if(scan.nextLine().equalsIgnoreCase("y")) { //check to see if the user input String "y" indicating they would like to re-enter
					System.out.println("Please enter the file name/path for the read file: "); //prompt user to re-enter file path to console
					input=scan.nextLine(); //store user input in the String input
				}
				else { //if user indicates they do not wish to continue, end the program
					termLoop=true; //set terminal loop to true
					break; //break from the do-while
				}
			}
		}
		while(!termLoop); //conditional for do-while
		return new Scanner(input); //return Scanner from String input
	}
	
	/**
	*The GetOutputFile method prompts the user to enter a file name or path for writing, attempts to create or open the specified output file, and returns a PrintWriter
	*object initialized to write to the file if successful
	*
	* CSC 1351 Programming Project No 1
	* Section 2
	*
	* @author Colton Elliott
	* @since 3/17/24
	*
	*/
	public static PrintWriter GetOutputFile(String UserPrompt) throws FileNotFoundException {
		String input=UserPrompt; //initialize String to store user input in
		boolean termLoop=false; //initializing a boolean terminal variable for do-while loop
		do { //iterate at least once before checking terminal value each iteration, until proper input is achieved with the try catch
			try {
				File writeFile=new File(input); //initialize a File called writeFile from the String input
				PrintWriter returnPrintWriter=new PrintWriter(writeFile); //try to create a PrintWriter to write to readFile
				System.out.println("File found. Writing to file."); //if the PrintWriter is created, print a message to console to notify
				return returnPrintWriter;
			}
			catch(Exception e) { //if an exception occurs
				System.out.println("File not found. Would you like to re-enter the file name/path?<y/n>: "); /*print message to console notifying failure to create PrintWriter
																											   and ask if the user would like to attempt to re-enter the 
																											   file path*/
				if(scan.nextLine().equalsIgnoreCase("y")) { //check to see if the user input String "y" indicating they would like to re-enter
					System.out.println("Please enter the file name/path for the write file: "); //prompt user to re-enter file path to console
					input=scan.nextLine(); //store user input in the String input
				}
				else { //if user indicates they do not wish to continue, end the program
					termLoop=true; //set terminal loop to true
					break; //break from the do-while
				}
			}
		}
		while(!termLoop); //conditional for do-while
		return new PrintWriter(input); //return PrintWriter from String input
	}
}
