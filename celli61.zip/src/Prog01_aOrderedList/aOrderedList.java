package Prog01_aOrderedList;

import java.util.Arrays;
import java.util.*;

/**
* aOrderedList is a generic ordered list that stores elements of type 'T', with methods for adding and removing elements, accessing elements,
* and iterating over the ordered list 
* 
* CSC 1351 Programming Project No 1
* Section 2
*
* @author Colton Elliott
* @since 3/17/24
*
*/
public class aOrderedList<T> {
	private T[] oList; //array for storage of elements of type T
	private int listSize; //stores the current size of the list
	private int curr; //stores the current index for iteration
	
	/**
	* The aOrderedList constructor initializes a new aOrderedList object 
	* of type T, and resets the iterator
	*
	* CSC 1351 Programming Project No 1
	* Section 2
	*
	* @author Colton Elliott
	* @since 3/17/24
	*
	*/
	public aOrderedList() {
		this.listSize=0; //sets current instance of listSize to 0
		this.oList=(T[]) new Comparable[listSize]; //sets current instance of oList to an Array of type T and length oList
		reset(); //resets iterator
	}
	
	/**
	* The add() method adds a new element to the list while maintaining order
	*
	* CSC 1351 Programming Project No 1
	* Section 2
	*
	* @author Colton Elliott
	* @since 3/17/24
	*
	*/
	public void add(T newObject) {
		oList=Arrays.copyOf(oList, oList.length+1); //creates a new array of one greater length with the same contents as oList
		this.listSize=oList.length; //sets current instance of listSize to new array length
		oList[oList.length-1]=newObject; //sets last index in new array to new element
		Arrays.sort(oList); //sort list
	}
	
	/**
	* The remove() method removes the element at the specified index from the list
	*
	* CSC 1351 Programming Project No 1
	* Section 2
	*
	* @author Colton Elliott
	* @since 3/17/24
	*
	*/
	public void remove(int index) {
		T[] newOList=(T[]) new Comparable[oList.length-1]; //creates a new array of type T of one less length
		this.listSize=newOList.length; //sets current instance of listSize to new array length
		for(int i=0;i<index;i++) { //initializes a for loop to iterate 0 to <index times
			newOList[i]=oList[i]; //sets index i to the value from the original array at index i 
		}
		for(int i=index+1;i<oList.length;i++) { //initializes a for loop to loop from one after the specified index to the end of the list
			newOList[i-1]=oList[i]; //sets the index i-1 of new array to the value from the original array at index i 
		}
		oList=Arrays.copyOf(newOList, newOList.length); //copies ArrayList into oList as an array
		Arrays.sort(oList); //sort the list
	}
	
	/**
	* The size() method returns the size of the list
	*
	* CSC 1351 Programming Project No 1
	* Section 2
	*
	* @author Colton Elliott
	* @since 3/17/24
	*
	*/
	public int size() {
		return this.listSize; //returns current instance of listSize
	}
	
	/**
	* The get(int index) method returns the element from the list at the specified index
	*
	* CSC 1351 Programming Project No 1
	* Section 2
	*
	* @author Colton Elliott
	* @since 3/17/24
	*
	*/
	public T get(int index) {
		return oList[index]; //returns value from oList at index index
	}
	
	/**
	* The isEmpty() method returns true if oList is empty
	*
	* CSC 1351 Programming Project No 1
	* Section 2
	*
	* @author Colton Elliott
	* @since 3/17/24
	*
	*/
	public boolean isEmpty() {
		return oList.length==0; //returns true if oList length is 0
	}
	
	/**
	* The next() method iterates over the list and returns the value iterated over
	*
	* CSC 1351 Programming Project No 1
	* Section 2
	*
	* @author Colton Elliott
	* @since 3/17/24
	*
	*/
	public T next() {
		curr++; //increments index of iterator
		return oList[curr]; //returns value of oList at index curr
	}
	
	/**
	* The hasNext() method returns true if there is an element in oList to be iterated over still and false if not
	*
	* CSC 1351 Programming Project No 1
	* Section 2
	*
	* @author Colton Elliott
	* @since 3/17/24
	*
	*/
	public boolean hasNext() {
		return curr+1<oList.length; //returns if the index after current index is out of bounds
	}
	
	/**
	* The reset() method resets the iteration index to the beginning of the list
	*
	* CSC 1351 Programming Project No 1
	* Section 2
	*
	* @author Colton Elliott
	* @since 3/17/24
	*
	*/
	public void reset() {
		curr=-1; //sets iteration index to -1
	}
	
	/**
	* The remove() method removes the element from the current index of iteration
	*
	* CSC 1351 Programming Project No 1
	* Section 2
	*
	* @author Colton Elliott
	* @since 3/17/24
	*
	*/
	public void remove() {
		if(curr!=-1) { //checks if at least one iteration has occurred
			remove(curr); //removes at index of iteration
		}
	}
	
	/**
	* The toString() method returns a string representation of all elements in the list
	*
	* CSC 1351 Programming Project No 1
	* Section 2
	*
	* @author Colton Elliott
	* @since 3/17/24
	*
	*/
	@Override
	public String toString() {
		String output=""; //creates a String to build to output
		for(int i=0;i<oList.length;i++) { //initializes a for loop to iterate 0 to <oList.length times
			output+="["+oList[i]+"], "; //adds value at current index of oList in brackets with a comma and space
		}
		return output.substring(0,output.length()-2); //returns output String
	}
}
