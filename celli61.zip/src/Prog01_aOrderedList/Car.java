package Prog01_aOrderedList;

/**
* Car is a comparable object containing information on a vehicle's make, year, and price and implements comparable,
* comparing based on make first, and then price
* 
* CSC 1351 Programming Project No 1
* Section 2
*
* @author Colton Elliott
* @since 3/17/24
*
*/
public class Car implements Comparable{
	private String make; //initializing a String to store the make of the car
	private int year; //initializing an int to store the year of the car
	private int price; //initializing an into to store the price of the car 
	
	/**
	* The Car constructor initializes a new Car object with the make, year, and price parameters
	*
	* CSC 1351 Programming Project No 1
	* Section 2
	*
	* @author Colton Elliott
	* @since 3/17/24
	*
	*/
	public Car(String make, int year, int price) {
		this.make=make; //sets current instance of make to the parameter make
		this.year=year; //sets current instance of year to the parameter year
		this.price=price; //sets current instance of price to the parameter price
	}
	
	/**
	* The getMake() method returns the make of the car
	*
	* CSC 1351 Programming Project No 1
	* Section 2
	*
	* @author Colton Elliott
	* @since 3/17/24
	*
	*/
	public String getMake() {
		return this.make; //return current instance of make;
	}
	
	/**
	* The getYear() method returns the year of the car 
	*
	* CSC 1351 Programming Project No 1
	* Section 2
	*
	* @author Colton Elliott
	* @since 3/17/24
	*
	*/
	public int getYear() {
		return this.year; //return current instance of year
	}
	
	/**
	* The getPrice() method returns the price of the car
	*
	* CSC 1351 Programming Project No 1
	* Section 2
	*
	* @author Colton Elliott
	* @since 3/17/24
	*
	*/
	public int getPrice() {
		return this.price; //returns current instance of price
	}
	
	/**
	* The compareTo() method compares one Car object with another Car object based on make first,
	* then price, returning a negative integer to indicate the first car is lesser, a 0 if they are the same,
	* and a positive integer if the first Car is greater
	*
	* CSC 1351 Programming Project No 1
	* Section 2
	*
	* @author Colton Elliott
	* @since 3/17/24
	*
	*/
	public int compareTo(Object other) {
		Car otherCar=(Car)other; //Storing the Object other in a Car object called otherCar
		if(this.getMake().compareTo(otherCar.getMake())<0) { //check if the make of the first car is less than the make of the second
			return -1; //return negative integer
		}
		else if(this.getMake().compareTo(otherCar.getMake())==0) { //if not, check if the makes are the same
			if(this.getYear()<otherCar.getYear()) { //if so, check if the year of the first is less than the year of the second
				return -1; //return negative integer
			}
			return 0; //return 0 
		} 
		else { //otherwise, the first Car must be larger
			return 1; //return positive integer
		}
	}
	
	/**
	* The toString() method returns a string representation of the Car object including
	* it's make, year, and price
	*
	* CSC 1351 Programming Project No 1
	* Section 2
	*
	* @author Colton Elliott
	* @since 3/17/24
	*
	*/
	public String toString() {
		return "Make: "+make+", Year: "+year+", Price: "+price+";";
	}
}
